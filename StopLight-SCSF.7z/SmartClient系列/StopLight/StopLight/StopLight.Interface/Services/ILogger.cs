﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//-----------------------------------------------------------------------
// <copyright file="ILogger.cs" company="FLYabroad Enterprises">
//     Copyright (c) FLYabroad. All rights reserved.
// </copyright>
// <author>FLYabroad(http://www.flyabroad111.com)</author>
//-----------------------------------------------------------------------
namespace SmartClient系列.StopLight.Interface.Services
{
    public interface ILogger
    {
        void Write(string message);
    }
}
