﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//-----------------------------------------------------------------------
// <copyright file="IStoplightTimer.cs" company="FLYabroad Enterprises">
//     Copyright (c) FLYabroad. All rights reserved.
// </copyright>
// <author>FLYabroad(http://www.flyabroad111.com)</author>
//-----------------------------------------------------------------------
namespace SmartClient系列.StopLight.Interface.Services
{
    public interface IStoplightTimer
    {
        TimeSpan Duration { get; set; }
        void Start();
        event EventHandler Expired;
    }
}
