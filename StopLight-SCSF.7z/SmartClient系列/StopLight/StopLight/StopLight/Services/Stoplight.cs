﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.ObjectBuilder;
using SmartClient系列.StopLight.Interface.Services;

//-----------------------------------------------------------------------
// <copyright file="Stoplight.cs" company="FLYabroad Enterprises">
//     Copyright (c) FLYabroad. All rights reserved.
// </copyright>
// <author>FLYabroad(http://www.flyabroad111.com)</author>
//-----------------------------------------------------------------------
namespace SmartClient系列.StopLight.Services
{
    public enum StoplightColors
    {
        Green,
        Yellow,
        Red
    }

    public class LightChangedEventArgs : EventArgs
    {
        private StoplightColors currentColor;

        public StoplightColors CurrentColor
        {
            get { return currentColor; }
            private set { currentColor = value; }
        }

        public LightChangedEventArgs(StoplightColors color)
        {
            CurrentColor = color;
        }
    }

    public delegate void StoplightChangedHandler(object sender, LightChangedEventArgs e);

    /// <summary>
    /// 负责核心业务操作，跟踪当前颜色，并确定下一个要显示的颜色
    /// </summary>
    public class Stoplight
    {
        public const StoplightColors Green = StoplightColors.Green;
        public const StoplightColors Yellow = StoplightColors.Yellow;
        public const StoplightColors Red = StoplightColors.Red;

        private StoplightColors currentColor = StoplightColors.Green;
        private ILogger logger = new NullLogger();
        public event StoplightChangedHandler Changed;

        public StoplightColors CurrentColor
        {
            get { return currentColor; }
        }

        /// <summary>
        /// Logger 是一个易变因素，通过依赖注入是我们更容易的指定当前要使用的 ILogger
        /// 通过 Unity 等 IOC 容器我们可以在部署时通过配置文件指定具体使用哪一个 ILogger
        /// </summary>
        [Dependency]
        public ILogger Logger
        {
            get { return logger; }
            set { logger = value; }
        }
        
        /// <summary>
        /// 切换到当前顺序的下一颜色并触发 Changed 事件（StoplightChangedHandler）
        /// 该事件在 StopLightViewPresenter 中注册并处理（OnStoplightChanged），功能是设置当前显示的颜色（CurrentColor）
        /// </summary>
        public void Next()
        {
            ++currentColor;
            if (currentColor > StoplightColors.Red)
            {
                currentColor = StoplightColors.Green;
            }
            RaiseChanged();
            logger.Write(string.Format("LIGHT CHANGED TO {0}", currentColor));
        }

        protected void RaiseChanged()
        {
            StoplightChangedHandler handlers = Changed;
            if (handlers != null)
            {
                LightChangedEventArgs e = new LightChangedEventArgs(currentColor);
                handlers(this, e);
            }
        }
    }
}
