﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SmartClient系列.StopLight.Interface.Services;
using System.Diagnostics;

//-----------------------------------------------------------------------
// <copyright file="TraceLogger.cs" company="FLYabroad Enterprises">
//     Copyright (c) FLYabroad. All rights reserved.
// </copyright>
// <author>FLYabroad(http://www.flyabroad111.com)</author>
//-----------------------------------------------------------------------
namespace SmartClient系列.StopLight.Services
{
    public class TraceLogger : ILogger
    {
        public void Write(string message)
        {
            Trace.WriteLine(string.Format("{0}: {1}",
                                          DateTime.Now,
                                          message));
        }
    }
}
