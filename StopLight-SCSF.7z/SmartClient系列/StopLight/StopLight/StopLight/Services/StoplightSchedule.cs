﻿using System;
using Microsoft.Practices.ObjectBuilder;
using SmartClient系列.StopLight.Interface.Services;

//-----------------------------------------------------------------------
// <copyright file="StoplightSchedule.cs" company="FLYabroad Enterprises">
//     Copyright (c) FLYabroad. All rights reserved.
// </copyright>
// <author>FLYabroad(http://www.flyabroad111.com)</author>
//-----------------------------------------------------------------------
namespace SmartClient系列.StopLight.Services
{
    /// <summary>
    /// 负责核心业务流程，决定如何初始化显示，何时开始显示，合适更改到下一颜色。
    /// </summary>
    public class StoplightSchedule
    {
        private IStoplightTimer timer;
        private ILogger logger = new NullLogger();
        private TimeSpan[] lightTimes = new TimeSpan[3];
        private int currentLight = 0;

        public event EventHandler ChangeLight;

        public StoplightSchedule(IStoplightTimer timer)
        {
            this.timer = timer;
            timer.Expired += OnTimerExpired;
        }

        /// <summary>
        /// Logger 是一个易变因素，通过依赖注入是我们更容易的指定当前要使用的 ILogger
        /// 通过 Unity 等 IOC 容器我们可以在部署时通过配置文件指定具体使用哪一个 ILogger
        /// </summary>
        [Dependency]
        public ILogger Logger
        {
            get { return logger; }
            set { logger = value; }
        }

        /// <summary>
        /// 启动定时器调动，定时器在时间间隔到后触发 Expired 事件（已绑定到 OnTimerExpired）
        /// 该方法在 StopLightViewPresenter 的 OnViewReady() 中调用，这时整个 View 初始化已经完成，可以工作了
        /// </summary>
        public void Start()
        {
            timer.Start();
        }

        /// <summary>
        /// 设置各颜色的显示时间间隔
        /// </summary>
        /// <param name="green"></param>
        /// <param name="yellow"></param>
        /// <param name="red"></param>
        public void Update(TimeSpan green, TimeSpan yellow, TimeSpan red)
        {
            lightTimes[0] = green;
            lightTimes[1] = yellow;
            lightTimes[2] = red;

            logger.Write(string.Format("UPDATE SCHEDULE: {0} {1} {2}", green, yellow, red));
        }

        /// <summary>
        /// 强制更改到下一要显示的颜色，逻辑上该操作等同于当前颜色的显示时间到期
        /// </summary>
        public void ForceChange()
        {
            OnTimerExpired(this, EventArgs.Empty);
            logger.Write(string.Format("FORCED CHANGE"));
        }

        /// <summary>
        /// 显示时间到期，触发 ChangeLight 事件，并将下一颜色的时间间隔附给 timer 。
        /// ChangeLight 事件在 StopLightViewPresenter 的 OnViewSet 中注册，监听器的工作很简单：执行 Stoplight.Next()
        /// Stoplight 的 Next 方法用于将下一要显示的颜色附给 View 的 CurrentColor
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks>显示间隔到后，通知监听者应该换到下一颜色了</remarks>
        private void OnTimerExpired(object sender, EventArgs e)
        {
            EventHandler handlers = ChangeLight;
            if (handlers != null)
            {
                handlers(this, EventArgs.Empty);
            }
            currentLight = (currentLight + 1) % 3;
            timer.Duration = lightTimes[currentLight];
            timer.Start();
        }
    }
}