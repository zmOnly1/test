﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SmartClient系列.StopLight.Interface.Services;

//-----------------------------------------------------------------------
// <copyright file="NullLogger.cs" company="FLYabroad Enterprises">
//     Copyright (c) FLYabroad. All rights reserved.
// </copyright>
// <author>FLYabroad(http://www.flyabroad111.com)</author>
//-----------------------------------------------------------------------
namespace SmartClient系列.StopLight.Services
{
    public class NullLogger : ILogger
    {
        public void Write(string message)
        {
        }
    }
}
